import os
import sys
import requests

# Define the repository URL
REPO_URL = "http://localhost:8000/"

def download_and_install(package_name):
    # Create the programs directory if it doesn't exist
    programs_dir = "programs"
    os.makedirs(programs_dir, exist_ok=True)
    
    # Construct the URL of the package
    package_url = f"{REPO_URL}/{package_name}/{package_name}.exe"
    
    # Define the local filename within the programs directory
    local_filename = os.path.join(programs_dir, f"{package_name}.exe")
    
    try:
        # Download the package
        print(f"Downloading {package_name} from {package_url}...")
        response = requests.get(package_url, stream=True)
        response.raise_for_status()

        # Write the package to a local file
        with open(local_filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        print(f"Downloaded {package_name} to {local_filename}")

        # Install the package
        print(f"Installing {package_name}...")
        os.system(local_filename)
        print(f"Installed {package_name}")

        # Note: Not deleting the local file to keep it in the programs directory

    except requests.exceptions.RequestException as e:
        print(f"Failed to download {package_name}: {e}")
    except Exception as e:
        print(f"Failed to install {package_name}: {e}")

def main():
    if len(sys.argv) != 3 or sys.argv[1] != '-S':
        print("Usage: python wpkg.py -S <package_name>")
        sys.exit(1)

    package_name = sys.argv[2].rstrip('/')
    download_and_install(package_name)

if __name__ == "__main__":
    main()

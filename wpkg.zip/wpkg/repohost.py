import os
import http.server
import socketserver

# Define the directory to be served
DIRECTORY = "repo"
PORT = 8000

class RepoRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

def start_server():
    os.makedirs(DIRECTORY, exist_ok=True)
    handler = RepoRequestHandler
    with socketserver.TCPServer(("", PORT), handler) as httpd:
        print(f"Serving HTTP on port {PORT} (http://localhost:{PORT}/) ...")
        httpd.serve_forever()

if __name__ == "__main__":
    start_server()

